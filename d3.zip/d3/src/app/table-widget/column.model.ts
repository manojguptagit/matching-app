export interface TableColumn {
    id: string;
    displayName: string;
    hide: boolean;
    drilldown: boolean;
}