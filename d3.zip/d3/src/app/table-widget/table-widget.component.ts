import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import * as d3 from 'd3';
import { TableColumn } from './column.model';
import { HttpClient } from '@angular/common/http';
import { element } from 'protractor';

@Component({
  selector: 'app-table-widget',
  templateUrl: './table-widget.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./table-widget.component.scss']
})
export class TableWidgetComponent implements OnInit {

  tableColumns: TableColumn[] = [
    {
      id: 'postId',
      displayName: 'Post ID',
      hide: false,
      drilldown: false
    },
    {
      id: 'id',
      displayName: 'Id',
      hide: false,
      drilldown: true
    }
    ,
    {
      id: 'name',
      displayName: 'Name',
      hide: false,
      drilldown: false
    }
    ,
    {
      id: 'email',
      displayName: 'Email',
      hide: false,
      drilldown: true
    }
    ,
    {
      id: 'body',
      displayName: 'Body',
      hide: false,
      drilldown: false
    }

  ];

  /**
   * Constructor
   * @param httpClient 
   */
  constructor(private httpClient: HttpClient) { }

  /**
   * Initialize data
   * 08308372224
   */
  initData(): void {
    this.httpClient.get<any[]>('https://jsonplaceholder.typicode.com/comments').subscribe(
      tableData => {
        let groupByColumns: string[] = ['postId'];
        let columnsObjectsToShow: TableColumn[] = this.tableColumns.filter(element => element.hide === false);
        let table = d3.select("#mydiv").append("table").classed('table', true).attr("style", "width: 100%;");
        let thead = table.append("thead");
        let tbody = table.append("tbody");
        let nestedDatas: any[] = [];


        groupByColumns.forEach(element => {
          let nestedData = d3.nest().key((data) => { return data[element] }).entries(tableData);
          nestedDatas.push(nestedData);
        });

        console.log(JSON.stringify(nestedDatas));

        // append the header row
        thead.append("tr")
          .selectAll("th")
          .data(columnsObjectsToShow)
          .enter()
          .append("th")
          .text((column) => { return column.displayName; });

        // create a row for each object in the data
        let rows = tbody.selectAll("tr")
          .data(tableData)
          .enter()
          .append("tr");

        // create a cell in each row for each column
        let cells = rows.selectAll("td")
          .data((rowData) => {
            return columnsObjectsToShow.map(col => col.id).map(column => {
              return { column: column, value: rowData[column], rowData: rowData, columnData: columnsObjectsToShow.filter(columnObject => columnObject.id === column)[0] };
            });
          })
          .enter()
          .append("td")
          .classed("clickable", (element) => {
            return element.columnData.drilldown;
          })
          .on('click', (data) => {
            if (data.columnData.drilldown) {
              console.log('Clicked on => ' + JSON.stringify(data));
            }
          })
          .text((data) => {
            return data.value;
          });
      },
      error => {
        console.error(error.error);
      }
    )
  }

  ngOnInit() {
    this.initData();
  }

  clicked($event): void {
    console.log($event);
  }

}
