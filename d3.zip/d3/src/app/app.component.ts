import { Component, OnInit } from '@angular/core';
import * as d3 from 'd3';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  ngOnInit(): void {
    /*  d3.select('#main')
      .data([10, 15, 20, 35, 80])
      .enter()
      .append('li')
      .attr('style', 'padding: 10px;')
      .text((value) => { return 'This value is ' + value }); */
  } 
}
